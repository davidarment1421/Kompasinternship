<template>

  <header>
    <nav class="navbar navbar-expand-lg navbar-light">
      <div class="container">
        <a href="/"
          ><img
            src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAFgAAAAZCAYAAAC1ken9AAAACXBIWXMAAAsTAAALEwEAmpwYAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAXxSURBVHgB7VhNaGRFEK7EoCjGHVcXRXR9HlxQ0J2DuuIlz/Ug6GETEQ+CJHtQdBESRfQgkrd4EFTIBBEUxGRBwYOYKB7FmfXv4CqTPeiiIPNEvDqzKqIX2692qpOaSnfPZA4ZUAs+ul9XdVV1db/qeo9ol8k5d5VgEriE+4pXATJgQp4nNX8HNsbM89U0Ihqn3acDwClgH3ArsB8B2AM8iP4DwG/A23jeK/Kvo/8Jd9DeDPwFHAb2ARvAQ8DLwJMiM4nmLW8Mz/eh+RPtC/RfICx0BvgQuBs4IGN8ar9RMhzgp6R/DPhZ+rOqPw78DlwqAa/L+GPAKaXrM9G/n0ZAozjBNwCXA/ePjY19L2PPAV8omWuACxCUC9F+C1yJ/iG0/Op/JTK3AR3gLuAY8DxkLkP7E89Vuj4HvgPupRHQKAJ8GHgRyBGQKRnjHHlGydwEvAPcAXwN/ELd1MJyflN4o05ik94FeLM+xvMzAKeW81kA+s/DOI/dCDxMI6BRBPh26p6qR4A3EISL0H4E/M1MPD+KpobA/ID2V7Sck/kUfwDwhtRFzy3Al14p5k1D9ml0PyUJMOhxvjhF13s0ApqgXSQs9go0HAQOwAbwEnA98CpwCPyDaM8gIK9xYNDfK1XEswBfXg3gD+HxiS9FLz/z5XcxWpZ/RXRx2rkH/TbaN+l/+veRrRfn0GQR2XWcrA2RmTK8ZeZRH5KTdgSyJwLjK0DFTClV/6z40IjonkdTpTC9j3nrYmdJ6etQmhreHlci7LvMi1EZ8887yYX+tNuiNlCVMqeiZHisycEGcs/rR5BbAloRHutZULbXZIxRU+P1kD2RmxefPbXEx6ry3drx69BoCm/BxCY3+msypue0ZDOiQdABrgf4mSw+riSsN/MOJGT0wo8YXpHyS8mtKbnZAewUAX5FAjkX4DXV3KqZ0+q3RnK9p6VmeEMFV+Z64y4ho4OTBWy7ATYpGICEnTwisxrY5Iqa1w7MqVm9oSrioOrX1WR2lg0eRZ7pl7us4UWK53ZNPiAd2CgNL1P9ksJ2KkZH7F7IVT8mwwE8G/EvNu9a1d9DESfb9gS47idqQUOQnDze2XrqBJvTsR7gryp+7NXPlUw94U9QBs/TlF6LTi21AL/lzBs2bgQ4oJsXiFQNfPoW0C9oOOJCf8HYCV2K+nQ0jDz74IO6bKsQRbnqn47IVEMy8krnlCY9t6ReH7k6yahbmcz48YmEgo5M4uA0aEiKvKYV2l4i5ao/JSf9Onnm122ZEmWaUDC9Jex0JLC+fFugNGn98+qgcNmaiY+1QHrrkknSTXXkmfoZT5JOES5wSRq+L89WxY/ZAW20UjYCdrhfqHnVPvo9cRrlamtO/Ku5QS5+Y7wQBVppfyXbdWYB3VlAzuf+thn3uXfFJeptN3iVocnX9rkLVAVmXlVvTMBuq98GWeO5jNVDigdwpq42Jjd6qgH5oA3Xu8lFwqau39cTfnlqGt4apdek/VgxvJZaa6Z540ooNzpLaY+rsXNfQZR2JKNu/stl6M5A3rQnMVP90xE/mOwnuqZc9RsDyPxoePbz3VYUwcvREK9rTg+MRxRs1qESHH0iFl06VRS0FcDjg/yjoN6FD/SWBEhfQDGb0UqF/1X4vutWLW4I/Uy6Fo4G2Cp4grZufQ5e8HWSwPtTViZKO1uEa+ftybLVRoz6fQRYO0EZObkFcHIH+vVz+GeQ6/3EXAnwdQ5iWgrILPk86rZ/6tbV3DnD26SIb/4CjP0o0rk1JlMx/od+GGWST5sJ/aFP5ELxC82bkGBm1LtDnGtXcAKP+gH0V8WpeZHnrxr+3cnppJDczM89OVdyO5/qXOlfVBuQqfGOBH/DpBa+B84V8jKP/SjFZ37W/ww4kOwj/6IsXfdCZehXl9+KadnPzM+j7scMt6vK/2kyuV/0n1C/DGoSl4qXZbu8hjEJWrD8CRXMskDvdNsYooh8TjujdatTAs+L4E1sgT8ji4+VRhvyDzgfwr7+D8w2KhGZUvmXUfefNvvDaa7JB/QfB1j21F0GLM4AAAAASUVORK5CYII="
            alt=""
            class=""
          />
        </a>
        <button
          class="navbar-toggler"
          type="button"
          data-bs-toggle="collapse"
          data-bs-target="#navbarSupportedContent"
          aria-controls="navbarSupportedContent"
          aria-expanded="false"
          aria-label="Toggle navigation"
        >
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="navbar-nav me-auto mb-2 mb-lg-0">
            <li class="nav-item">
              <router-link
                active-class="nav-active" class="nav-link" to="/" >Tujuan Kami</router-link>
            </li>
            <li class="nav-item">
              <router-link active-class="nav-active" class="nav-link" to="/" >Lowongan Kerja</router-link>
            </li>
            <li class="nav-item">
              <router-link active-class="nav-active" class="nav-link" to="/">Nilai-Nilai Kompas</router-link>
            </li>
            <li class="nav-item"> <router-link active-class="nav-active" class="nav-link" to="/">Keseharian Kami</router-link>
            </li>
            <li class="nav-item"><router-link active-class="nav-active" class="nav-link" to="/">Mengenal Kami</router-link>
            </li>
          </ul>
        </div>
      </div>
      
      
    </nav>
  </header>
  
</template>

<script>
export default {
  name: "Navbar",
};
</script>

<style scoped>
header {
  background-color: #1662a0;
  padding: 20px 0;
  position: fixed;
  top: 0;
  right: 0;
  left: 0;
  z-index: 20;
}
nav {
  display: flex;
  width: 70%;
  margin: 0 auto;
  color: #fff;
}
nav * {
  margin-right: 20px;
}
nav a {
  margin-top: 15px;
}
.nav-link {
  text-decoration: none;
  color: #fff;
  opacity: 1;
}
.nav-active {
  opacity: 1;
}
</style>