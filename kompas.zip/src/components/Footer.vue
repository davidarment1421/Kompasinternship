<template>
	<footer>
		<p>copyright &#169; 2021 by David</p>
	</footer>
</template>

<script>
export default {
	name: 'Footer',
};
</script>

<style scoped>
footer {
	text-align: center;
	padding: 30px;
	background-color: #1662a0;
	color: #fff;
	margin-top: 15%;
}
</style>